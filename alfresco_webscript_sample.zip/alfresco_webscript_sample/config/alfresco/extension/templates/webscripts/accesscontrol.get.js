
var userName=args["user"];
var nodeRef= args["node"];

var scriptNode=search.findNode(nodeRef);

scriptNode.setPermission("Read",username);

